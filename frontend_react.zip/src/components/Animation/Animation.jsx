import React from "react";
import "./Animation.scss";

const Animation = () => {
    return (
        <section className="bg-all">
            <span className="bg-star"></span>
            <span className="bg-star"></span>
            <span className="bg-star"></span>
            <span className="bg-star"></span>
            <span className="bg-star"></span>
            <span className="bg-star"></span>
            <span className="bg-star"></span>
            <span className="bg-star"></span>
            <span className="bg-star"></span>
            <span className="bg-star"></span>
        </section>
    );
};

export default Animation;
