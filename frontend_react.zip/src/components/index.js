import Navbar from "./Navbar/Navbar";
import NavigationDots from "./NavigationDots";
import SocialMedia from "./SocialMedia";

export { NavigationDots, SocialMedia, Navbar };
