import React from "react";
import { Navbar, Cer, Footer } from "../../container";
const Certificate = () => {
    return (
        <>
            <div className="app">
                <Navbar />
                <Cer />
                <Footer />
            </div>
        </>
    );
};

export default Certificate;
