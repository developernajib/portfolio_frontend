export { default as Navbar } from "../components/Navbar/Navbar";
export { default as Header } from "./Header/Header";
export { default as About } from "./About/About";
export { default as Service } from "./Service/Service";
export { default as Work } from "./Work/Work";
export { default as Skills } from "./Skills/Skills";
export { default as Testimonial } from "./Testimonial/Testimonial";
export { default as Contact } from "./Contact/Contact";
export { default as Footer } from "./Footer/Footer";

export { default as Cer } from "./Cer/Cer";
